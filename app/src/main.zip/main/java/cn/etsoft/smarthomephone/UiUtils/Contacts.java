package cn.etsoft.smarthomephone.UiUtils;

/**
 * Created by Say GoBay on 2016/9/2.
 */
public interface Contacts {
    //初次进入智能客房
    public static final String FIRST_ENTER="first_enter";
}
