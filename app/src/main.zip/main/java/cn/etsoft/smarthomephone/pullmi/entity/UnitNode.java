package cn.etsoft.smarthomephone.pullmi.entity;

import android.widget.Button;

public class UnitNode {

	/*
	 * canCpuId 12
	 * devName 12
	 * roomName 12
	 * devType 1
	 * devid 1
	 * devCtrlType 1
	 */
	public int id;
	public String canCpuId;
	public String devName;
	public String roomName;
	public int devType;
	public int devId;
	public int devCtrlType;
	public Button pBtn;
	
	
}
