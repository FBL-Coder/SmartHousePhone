package cn.etsoft.smarthomephone.domain;

/**
 * Created by fbl on 16-12-16.
 */
public class Weather_Bean {

    private int code;
    private int weather;

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getWeather() {
        return weather;
    }

    public void setWeather(int weather) {
        this.weather = weather;
    }
}
