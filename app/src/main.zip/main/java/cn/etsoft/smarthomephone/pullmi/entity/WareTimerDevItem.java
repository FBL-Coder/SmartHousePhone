package cn.etsoft.smarthomephone.pullmi.entity;

public class WareTimerDevItem {
	public byte[] uid;
	public byte devID;
	public byte bOnOff;
	public byte param1;
	public byte param2;
}
