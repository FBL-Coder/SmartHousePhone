package cn.etsoft.smarthomephone.Fragment;

import android.support.v4.app.Fragment;

/**
 * Created by Say GoBay on 2016/8/25.
 */
public class InfraredFragment extends Fragment {
}
