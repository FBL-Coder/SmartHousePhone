package cn.etsoft.smarthomephone.domain;

/**
 * Created by Say GoBay on 2016/12/22.
 */
public class User {
    String id;
    String pass;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }
}
