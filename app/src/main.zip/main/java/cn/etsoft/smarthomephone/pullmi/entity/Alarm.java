package cn.etsoft.smarthomephone.pullmi.entity;

public class Alarm {

	public long alarmDate;
	public int type;
	public String content;
	public int id;
	public int sn;
	public String from;
}
