package cn.etsoft.smarthomephone.pullmi.entity;

public class GPIO_INFO {
	private byte[] pPort;//
	public int ioPin;//
	public int rev;
}
