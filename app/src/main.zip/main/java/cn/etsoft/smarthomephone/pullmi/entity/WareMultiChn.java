package cn.etsoft.smarthomephone.pullmi.entity;

public class WareMultiChn {
	private byte bOnOff;
	private byte itemCnt;
	private byte rev2;
	private byte rev3;

	public byte getbOnOff() {
		return bOnOff;
	}

	public void setbOnOff(byte bOnOff) {
		this.bOnOff = bOnOff;
	}

	public byte getItemCnt() {
		return itemCnt;
	}

	public void setItemCnt(byte itemCnt) {
		this.itemCnt = itemCnt;
	}

	public byte getRev2() {
		return rev2;
	}

	public void setRev2(byte rev2) {
		this.rev2 = rev2;
	}

	public byte getRev3() {
		return rev3;
	}

	public void setRev3(byte rev3) {
		this.rev3 = rev3;
	}
}
