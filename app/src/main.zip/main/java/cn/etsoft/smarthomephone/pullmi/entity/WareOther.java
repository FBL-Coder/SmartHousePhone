package cn.etsoft.smarthomephone.pullmi.entity;

public class WareOther {		
		public WareDev  dev;	
		public int  type;//
		public int  rev1;
		public int  rev2;
		public int  rev3;
		public byte keyName[];
}
