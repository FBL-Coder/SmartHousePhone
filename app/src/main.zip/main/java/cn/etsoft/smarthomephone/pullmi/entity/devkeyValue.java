package cn.etsoft.smarthomephone.pullmi.entity;

public class devkeyValue {
	public String boardName; //12
	public String keyName;	 //12
	public byte cmd;
	public String cmdName;
	public String op;
}
