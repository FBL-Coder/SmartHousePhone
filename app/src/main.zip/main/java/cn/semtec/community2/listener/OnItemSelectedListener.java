package cn.semtec.community2.listener;


public interface OnItemSelectedListener {
    void onItemSelected(int index);
}
