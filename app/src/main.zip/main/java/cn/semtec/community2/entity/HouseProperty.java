package cn.semtec.community2.entity;

/**
 * Created by Ladystyle005 on 2016/7/19.
 */
public class HouseProperty {
    public String sipaddr; //sip地址
    public String communityName;  //社区名称
    public String roomName;  //房间
    public String buildName;    //单元号
    public String blockName;    //楼栋
    public String sipnum;       //sip号码
    public String sippassword;  //sip密码
    public String isMainSip;    //
    public int userType;     //用户类型  1是业主，2是户主，3是普通用户
    public String houseId;      //房的id
    public String userName;     //用户名
}
